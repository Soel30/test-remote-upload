<?php
error_reporting(E_ALL ^ E_WARNING ^ E_NOTICE);
define('APP_NAME', 'MangaKyu');
define('APP_DESCRIPTION', 'Example');
define('APP_URL', 'http://agc.soel');
define('DISQUS_SHORTNAME', 'example');
define('SCRAPE_URL', "https://www.readm.org");
define('CDN_URL', "http://localhost/img.php");
define('VIEW_PATH', __DIR__ . '/src/Views');
