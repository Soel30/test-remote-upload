<?php

namespace App\Controllers;

use App\Helpers\Helpers;
use App\Lib\Scrapper;

class IndexController
{

  protected $init;

  public function __construct()
  {
    $this->init = new Scrapper();
  }

  public function index()
  {
    $data = $this->init->getHome();
    $title = 'Jembot';
    // echo json_encode($data);
    return Helpers::view('index', $data, $title);
  }

  public function latest()
  {
    $data = $this->init->getLatest();
    $title = "Latest Manga Release";
    return Helpers::view('latest', $data, $title);
  }

  public function latestPage($slug)
  {
    $data = $this->init->getLatestPage($slug);
    $title = "Latest Manga Release";
    return Helpers::view('latest', $data, $title);
  }

  public function mangalist()
  {
    $data = $this->init->mangaList();
    $title = "Manga List";
    return Helpers::view('list', $data, $title);
  }

  public function mangalistSearch($slug)
  {
    $data = $this->init->mangaListSearch($slug);
    $title = "Manga List";
    return Helpers::view('list', $data, $title);
  }

  public function popular()
  {
    $data = $this->init->popularManga();
    $title = "Popular Manga";
    return Helpers::view('popular', $data, $title);
  }

  public function popularSlug($slug)
  {
    $data = $this->init->popularMangaList($slug);
    $title = "Popular Manga";
    return Helpers::view('popular', $data, $title);
  }

  public function detail($slug)
  {
    $data = $this->init->getDetail(explode('-a-', $slug)[0]);
    $title = $data['title'];
    return Helpers::view('detail', $data, $title);
  }

  public function read($slug, $chapter)
  {
    $data = $this->init->readChapter($slug, $chapter);
    $title = $data['title'];
    if (!$title) {
      return $this->notFound();
    }
    return Helpers::view('read', $data, $title);
  }

  public function genres($slug)
  {
    $data = $this->init->getGenreList($slug);
    $title = "Genre Manga";
    return Helpers::view('popular', $data, $title);
  }

  public function genresPage($slug, $page)
  {
    $data = $this->init->getGenreListPage($slug, $page);
    $title = "Genre Manga";
    return Helpers::view('popular', $data, $title);
  }


  public function notFound()
  {
    header('HTTP/1.1 404 Not Found');
    $title = "Page Not Found";
    return Helpers::view('404', null, $title);
  }

  public function search()
  {
    $search =  $_GET['s'];
    $data = $this->init->search($search);
    $title = "Your searcher for " . $search;
    return Helpers::view('search', $data, $title);
  }
}
