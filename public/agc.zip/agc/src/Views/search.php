<?php

use Ausi\SlugGenerator\SlugGenerator;

$generator = new SlugGenerator;
?>

<?php include(__DIR__ . '/layouts/header.php'); ?>

<div class="lg:px-28 px-7 md:px-14 mt-10">
    <main class=" mt-5 flex gap-4 rounded-xl ml-3 pt-4 pb-10 lg:flex-row flex-col">
        <div class=" w-full lg:w-8/12 ">
            <h2 class="m-0 text-gray-600 font-bold text-xl">Comics Search results for "<span class="font-extrabold text-red-400"><?php echo $_GET['s'] ?></span>"</h2>
            <div class="mt-3 flex gap-2 flex-col lg:flex-row lg:flex-wrap sm:flex-row sm:flex-wrap">
                <?php foreach ($data['manga'] as $manga) { ?>
                    <div class="w-full relative oys sm:w-2/6 md:w-1/6  has-tooltip">
                        <span class='tooltip hidden lg:block transition duration-200 rounded  py-2 px-3 bg-red-400 -ml-12 -mt-14 text-sm  font-semibold text-white z-50 shadow-3xl'>
                            <?php echo $manga['title'] ?>
                        </span>
                        <a href="<?php echo $manga['url'] . "-a-" . $generator->generate($manga['title']) ?>" class=" text-gray-500 hover:text-red-400 transition duration-200">
                            <div class="rounded shadow-xl bg-black opacity-20 absolute hover:opacity-0 transition duration-200 w-full h-48 z-40"></div>
                            <img class="w-full object-cover h-48 rounded coklah" data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $manga['image'] ?>" alt="<?php echo $manga['title'] ?>">
                            <div class="m-3 font-semibold  transition duration-200 truncate">

                                <?php echo $manga['title'] ?>
                            </div>
                        </a>
                    </div>
                <?php } ?>
            </div>
        </div>
        <div class="w-full lg:w-4/12">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
            <div class="mt-2">
                <ul class="flex flex-wrap gap-2">
                    <?php foreach ($data['genres'] as $genre) { ?>
                        <li style="width: 48.7%;"><a href="/genres/<?php echo $genre ?>" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </main>
</div>
<?php include(__DIR__ . '/layouts/footer.php'); ?>