<?php include(__DIR__ . '/layouts/header.php'); ?>


<div class="lg:px-28 px-7 md:px-14 mt-10">
    <div>
        <h2 class="m-0 ml-3 py-4 text-gray-600 mt-5 font-bold text-xl"><span class="font-extrabold text-red-400">Popular</span> Manga</h2>
        <div class="main-carousel  gap-4" data-flickity='{ "cellAlign": "left", "wrapAround": true, "contain": true, "pageDots": false, "autoPlay": true}'>
            <?php foreach ($data['popular'] as $popular) { ?>
                <div class="w-12/12 sm:w-4/12 md:w-3/12 lg:w-2/12  ml-2 relative ">
                    <a href="<?php echo $popular['manga']['url'] ?>" class=" text-gray-500 hover:text-red-400 transition duration-200">
                        <div class=" rounded-2xl shadow-xl bg-black opacity-20 absolute hover:opacity-0 transition duration-200 w-full h-60 " style="z-index: 99999999999;"></div>
                        <img class="rounded-2xl w-full h-60 object-cover shadow-xl" src="<?php echo CDN_URL ?>?url=<?php echo $popular['manga']['img'] ?>" alt="">
                        <div class="m-3 font-semibold  transition duration-200 truncate">
                            <?php echo $popular['manga']['title'] ?>
                        </div>
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
    <div class=" mt-2  gap-4 rounded-xl ml-3 pt-4 pb-10 ">
        <h2 class="m-0 py-4 text-gray-600 mt-5 font-bold text-xl"><span class="font-extrabold text-red-400">Recently</span> Added Manga</h2>
        <div class="flex  gap-3 justify-center flex-col lg:flex-row lg:flex-wrap sm:flex-row sm:flex-wrap">
            <?php foreach ($data['recently'] as $recent) { ?>
                <div class="w-full relative oys sm:w-2/6 md:w-1/6">
                    <a href="<?php echo $recent['url'] ?>" class=" text-gray-500 hover:text-red-400 transition duration-200">
                        <div class=" rounded-2xl shadow-xl bg-black opacity-20 absolute hover:opacity-0 transition duration-200 w-full h-60 " style="z-index: 99999999999;"></div>
                        <img class="w-full object-cover h-60 rounded coklah" data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $recent['img'] ?>" alt="<?php echo $recent['title'] ?>">
                        <div class="m-3 font-semibold  transition duration-200 truncate">
                            <?php echo $recent['title'] ?>
                        </div>
                    </a>
                </div>
            <?php } ?>
        </div>
    </div>
    <main class=" mt-5 flex gap-4 rounded-xl ml-3 pt-4 pb-10 lg:flex-row flex-col">
        <div class=" w-full lg:w-8/12 ">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Latest</span> Update</h2>
            <div class="mt-2 flex gap-2 flex-col lg:flex-wrap lg:flex-row">
                <?php foreach ($data['latest'] as $latest) { ?>
                    <div class="bg-gray-500 text-white px-2 rounded py-2 flex pant">
                        <img class="rounded-full w-16 h-16 object-cover lg:w-16 lg:h-16 coklah" alt="<?php echo $latest['manga']['img'] ?>" data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $latest['manga']['img'] ?>" alt="">
                        <div style="width: 70%;" class="flex flex-col justify-center">
                            <a href="<?php echo $latest['manga']['url'] ?>">
                                <div class="m-3 mt-1 truncate has-tooltip font-semibold">
                                    <span class='tooltip hidden lg:block transition duration-200 rounded shadow-2xl py-2 px-3 bg-red-400 -ml-12 -mt-14 text-sm  font-semibold text-white'>
                                        <?php echo $latest['manga']['title'] ?>
                                    </span>
                                    <?php echo $latest['manga']['title'] ?>
                                </div>
                            </a>
                            <div class="flex ml-4 gap-2 flex-wrap">
                                <?php foreach ($latest['chapter'] as $chLatest) { ?>
                                    <a href="<?php echo str_replace('/all-pages', '', str_replace('manga', 'read', $chLatest['url'])) ?>" class="border-2 hover:bg-red-400 hover:border-transparent transition duration-200 rounded" style="padding: 0.20rem;font-size: 12px;"><?php echo $chLatest['title'] ?></a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <a href="/latest-releases/2">
                <div class="bg-gray-500 text-white text-sm text-center mt-8 rounded px-3 py-2">Show More</div>
            </a>
        </div>
        <div class="w-full lg:w-4/12">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
            <div class="mt-2">
                <ul class="flex flex-wrap gap-2">
                    <?php foreach ($data['genres'] as $genre) { ?>
                        <li style="width: 48.7%;"><a href="/genres/<?php echo $genre ?>" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </main>
</div>


<script src="https://npmcdn.com/flickity@2/dist/flickity.pkgd.js"></script>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <div id="disqus_thread"></div>
</div>
<script>
    /**
     *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
     *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
        var d = document,
            s = d.createElement('script');
        s.src = 'https://dramayu-1.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<?php include(__DIR__ . '/layouts/footer.php'); ?>