<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="profile" href="https://gmpg.org/xfn/11">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito:500,600,700,900&display=swap">
  <link rel="stylesheet" href="/assets/styles.css">
  <?php if (@$title) { ?>
    <title><?php echo $title . ' | ' .  APP_NAME; ?></title>
  <?php } else { ?>
    <title><?php echo APP_NAME; ?></title>
  <?php } ?>
  <?php if (@$metas) echo $metas;
  else { ?>
    <meta name="description" content="<?php echo APP_DESCRIPTION; ?>">
    <meta name="keywords" content="<?php echo APP_NAME; ?>">
  <?php } ?>
  <link rel="stylesheet" href="/assets/flickity.css">
  <link rel="stylesheet" href="/assets/cust.css">
  <script src="https://cdn.jsdelivr.net/npm/lazyload@2.0.0-rc.2/lazyload.js"></script>
</head>

<body class="bg-gray-200" style="background-image: url('https://anime-indo.cc/backg.png');">
  <style>
    .tooltip {
      visibility: hidden;
      position: absolute;
    }

    .has-tooltip:hover .tooltip {
      visibility: visible;
      z-index: 50;
    }

    @media only screen and (min-width: 1024px) {
      .pant {
        width: 32%;
      }

      .oys {
        width: 15.666667%;
      }
    }
  </style>
  <style>
    .search:focus {
      width: 20rem;
    }

    .search {
      -webkit-transition: all .4s;
      -moz-transition: all .4s;
      -ms-transition: all .4s;
      -o-transition: all .4s;
      transition: all .4s;
    }

    .euy {
      left: -100000px;
      -webkit-transition: all .6s;
      -moz-transition: all .6s;
      -ms-transition: all .6s;
      -o-transition: all .6s;
      transition: all .6s;
    }

    .cok {
      left: 0px;
      -webkit-transition: all .2s ease-out;
      -moz-transition: all .2s ease-out;
      -ms-transition: all .2s ease-out;
      -o-transition: all .2s ease-out;
      transition: all .2s ease-out;
    }
  </style>
  <nav class="bg-white flex justify-between" style="background-image: url('https://cdn.staticaly.com/img/4.bp.blogspot.com/-alPKtyxQxTg/W4Zg9GsK5rI/AAAAAAAAAM4/0GbDlvV_7S4l6zF4PAFXGCjCMRWOMSHPgCLcBGAs/s1600/heleh+maling+sia.png');">
    <div class="bg-red-100 text-center items-center flex px-4 text-gray-600 md:hidden lg:hidden">
      <input type="checkbox" id="showmenu" hidden>
      <label for="showmenu">
        <i class="fas fa-stream"></i>
      </label>
    </div>
    <div class="relative py-3 flex justify-between items-center flex-col lg:mx-32 md:flex-row md:mx-11 sm:flex-col sm:mx-11 w-full">
      <div class="flex items-center content-center gap-8 ">
        <a href="/" class="text-red-400 font-bold text-2xl"><?php echo APP_NAME ?></a>
        <div class="hidden md:block">
          <form action="/search">
            <input name="s" type="text" class="search bg-gray-100 focus:border-transparent focus:outline-none px-3 w-72 py-2 mt-1 text-gray-400 text-sm" placeholder="Search">
          </form>
        </div>
      </div>
      <ul class="hidden md:flex gap-4">
        <li class="font-bold text-red-400"><a href="/">Home</a></li>
        <li class="font-bold text-red-400">
          <a href="/popular-manga">Popular Manga</a>
        </li>
        <li class="font-bold text-red-400">
          <a href="/latest-releases">Latest releases</a>
        </li>
      </ul>
    </div>
    <div class="bg-red-100 text-center items-center flex px-4 text-gray-600 md:hidden lg:hidden">
      <input type="checkbox" id="showsearch" hidden>
      <label for="showsearch">
        <i class="fas fa-search"></i>
      </label>
    </div>
    <ul class="px-5 text-sm py-5 md:hidden navigation absolute euy flex flex-col bg-white border-t-2 border-red-400 w-full z-40 top-14  md:relative gap-4 ">
      <li class="font-bold text-red-400">Home</li>
      <li class="font-bold text-red-400">
        <a href="/popular-manga">Popular Manga</a>
      </li>
      <li class="font-bold text-red-400">
        <a href="/latest-releases">Latest Release</a>
      </li>
    </ul>
    <div class="px-5 text-sm py-5 md:hidden serachlah euy absolute  flex flex-col bg-white border-t-2 border-red-400 w-full z-40 top-14  md:relative gap-4 ">
      <form action="/search">
        <input type="text" name="s" class=" bg-gray-100 focus:border-transparent focus:outline-none px-3 w-full py-2 mt-1 text-gray-400 text-sm" placeholder="Search">
      </form>
    </div>
  </nav>
  <div class="w-full bg-red-400 text-center py-1 font-semibold text-white ">
    <h1>Welcome to <?php echo APP_NAME ?></h1>
  </div>