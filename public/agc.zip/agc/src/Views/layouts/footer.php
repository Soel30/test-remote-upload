<footer class="bg-gray-600 px-28 py-2 text-white mt-10">
    <div class="flex justify-between gap-3">
        <h1><?php echo APP_NAME ?></h1>
        <h1>Created with ❤ by <a href="https://facebook.com/sultan.achmad.8">Soel</a> :D</h1>
    </div>
</footer>
<script>
    let images = document.querySelectorAll(".coklah");
    lazyload(images);
</script>
<script src="/assets/app.js"></script>
<script>
    var menu = document.querySelector('#showmenu');
    var search = document.querySelector('#showsearch');

    menu.onclick = function() {
        if (document.querySelector(".navigation").classList.contains("euy")) {
            document.querySelector(".navigation").classList.remove("euy")
            document.querySelector(".navigation").classList.toggle("cok")
            if (document.querySelector(".serachlah").classList.contains("cok")) {
                document.querySelector(".serachlah").classList.remove("cok")
                document.querySelector(".serachlah").classList.toggle("euy")
            }
        } else if (document.querySelector(".navigation").classList.contains("cok")) {
            document.querySelector(".navigation").classList.remove("cok")
            document.querySelector(".navigation").classList.toggle("euy")
        }
    }
    search.onclick = function() {
        if (document.querySelector(".serachlah").classList.contains("euy")) {
            document.querySelector(".serachlah").classList.remove("euy")
            document.querySelector(".serachlah").classList.toggle("cok")
            if (document.querySelector(".navigation").classList.contains("cok")) {
                document.querySelector(".navigation").classList.remove("cok")
                document.querySelector(".navigation").classList.toggle("euy")
            }
        } else if (document.querySelector(".serachlah").classList.contains("cok")) {
            document.querySelector(".serachlah").classList.remove("cok")
            document.querySelector(".serachlah").classList.toggle("euy")
        }
    }
</script>
<script src="https://kit.fontawesome.com/a549d09f73.js" crossorigin="anonymous"></script>
</body>

</html>
