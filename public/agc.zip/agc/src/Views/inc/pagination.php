<div class="bg-white  py-3 flex items-center justify-between border-t border-gray-200 px-6 mt-5 rounded">
    <div class="flex items-center justify-between">
        <div>
            <nav class="relative z-0 inline-flex rounded-md shadow-sm -space-x-px flex-wrap sm:flex-row" aria-label="Pagination">
                <?php foreach ($data['pagination'] as $item) { ?>
                    <?php if ($item['active'] == $item['text']) { ?>
                        <a href="#" aria-current="page" class="z-10 bg-indigo-50 border-indigo-500 text-indigo-600 relative inline-flex items-center px-4 py-2 border text-sm font-medium">
                        <?php } else { ?>
                            <a href=" <?php echo $item['url'] == '#' ? "/latest-releases/#" : $item['url'] ?>" class="bg-white border-gray-300 text-gray-500 hover:bg-gray-50 inline-flex relative items-center px-4 py-2 border text-sm font-medium">
                            <?php } ?>
                            <?php echo $item['text'] ?>
                            </a>
                        <?php } ?>
            </nav>
        </div>
    </div>
</div>