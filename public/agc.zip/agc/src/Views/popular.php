<?php include(__DIR__ . '/layouts/header.php'); ?>

<style>
    .tooltip {
        visibility: hidden;
        position: absolute;
    }

    .has-tooltip:hover .tooltip {
        visibility: visible;
        z-index: 50;
    }

    @media only screen and (min-width: 1024px) {
        .pant {
            width: 32%;
        }

        .oys {
            width: 15.666667%;
        }
    }
</style>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <main class=" mt-5 flex gap-4 rounded-xl ml-3 pt-4 pb-10 lg:flex-row flex-col">
        <div class=" w-full lg:w-8/12 ">
            <?php if ($data['title'] != "") { ?>
                <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400"><?php echo $data['title'] ?></span> Manga</h2>
            <?php } else {  ?>
                <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Popular</span> Manga</h2>
            <?php } ?>
            <div class="mt-2 flex gap-2 flex-col">
                <?php foreach ($data['manga'] as $item) { ?>
                    <div class="flex flex-col md:flex-row gap-3 border-2 border-gray-300 p-2 ">
                        <img class="w-full md:w-3/12 object-cover h-60 rounded" src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $item['img'] ?>" alt="<?php echo $item['title'] ?>">
                        <div class="w-full md:w-9/12">
                            <h1 class="text-lg font-semibold"><a href="<?php echo $item['url'] ?>"><?php echo $item['title'] ?></a></h1>
                            <span class="text-red-400 font-semibold text-sm">
                                <?php foreach ($item['genre'] as $genre) { ?>
                                    <a href="/genres/<?php echo $genre ?>" class=""><?php echo $genre ?></a>
                                <?php } ?>
                            </span>
                            <p class="overflow-hidden h-24 mt-2">
                                <?php echo $item['desc'] ?> </p>
                            </p>
                            <div class="mt-3">
                                <ul>
                                    <li class="text-sm font-semibold text-gray-400 hover:text-red-400"> <span class="text-base font-semibold text-gray-500">Type : </span><?php echo $item['type'] ?></li>
                                    <li class="text-sm font-semibold text-gray-400 hover:text-red-400"> <span class="text-base font-semibold text-gray-500">Rating : </span><?php echo $item['rating'] ?></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <?php include __DIR__ . '/inc/pagination.php'; ?>
        </div>
        <div class="w-full lg:w-4/12">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
            <div class="mt-2">
                <ul class="flex flex-wrap gap-2">
                    <?php foreach ($data['genres'] as $genre) { ?>
                        <li style="width: 48.7%;"><a href="/genres/<?php echo $genre ?>" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </main>
</div>
<?php include(__DIR__ . '/layouts/footer.php'); ?>