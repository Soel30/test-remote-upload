<?php include(__DIR__ . '/layouts/header.php'); ?>

<style>
    .tooltip {
        visibility: hidden;
        position: absolute;
    }

    .has-tooltip:hover .tooltip {
        visibility: visible;
        z-index: 50;
    }

    @media only screen and (min-width: 1024px) {
        .pant {
            width: 32%;
        }

        .oys {
            width: 15.666667%;
        }
    }
</style>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <main class=" mt-5 flex gap-4 rounded-xl ml-3 pt-4 pb-10 lg:flex-row flex-col">
        <div class=" w-full lg:w-8/12 ">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Manga</span> List</h2>
            <div class=" mb-4">
                <ul class="flex gap-1 justify-center flex-wrap">
                    <li class="mt-4"><a class="bg-gray-500 text-white px-3 py-2 rounded-lg" href="/manga-list/">#</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/A">A</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/B">B</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/C">C</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/D">D</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/E">E</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/F">F</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/G">G</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/H">H</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/I">I</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/J">J</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/K">K</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/L">L</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/M">M</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/N">N</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/O">O</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/P">P</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/Q">Q</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/R">R</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/S">S</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/T">T</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/U">U</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/V">V</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/W">W</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/X">X</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/Y">Y</a></li>
                    <li class="mt-4"><a class="bg-gray-700 hover:bg-gray-500 transition duration-200 text-white px-3 py-2 rounded-lg" href="/manga-list/Z">Z</a></li>

                </ul>
            </div>
            <div class="mt-2 flex gap-2 flex-col lg:flex-wrap lg:flex-row">
                <?php foreach ($data['list'] as $list) { ?>
                    <div class="bg-gray-500 text-white px-2 rounded py-2 flex pant">
                        <img class="rounded-full w-16 h-16 object-cover lg:w-16 lg:h-16" alt="<?php echo $list['manga']['title'] ?>" src="<?php echo CDN_URL . '?url=https://www.readm.org/' . $list['manga']['img'] ?? '' ?>" alt="">
                        <div style="width: 70%;" class="flex flex-col justify-center">
                            <a href="<?php echo $list['manga']['url'] ?>">
                                <div class="m-3 mt-1 truncate has-tooltip font-semibold">
                                    <span class='tooltip hidden lg:block transition duration-200 rounded shadow-2xl py-2 px-3 bg-red-400 -ml-12 -mt-14 text-sm  font-semibold text-white'>
                                        <?php echo $list['manga']['title'] ?>
                                    </span>
                                    <?php echo $list['manga']['title'] ?>
                                </div>
                                <h1 class="text-sm ml-4 -mt-2"><?php echo $list['manga']['staux'] ?></h1>
                            </a>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <?php include __DIR__ . '/inc/pagination.php'; ?>

        </div>
        <div class="w-full lg:w-4/12">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
            <div class="mt-2">
                <ul class="flex flex-wrap gap-2">
                    <?php foreach ($data['genres'] as $genre) { ?>
                        <li style="width: 48.7%;"><a href="" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </main>
</div>
<?php include(__DIR__ . '/layouts/footer.php'); ?>