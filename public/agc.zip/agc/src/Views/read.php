<?php include(__DIR__ . '/layouts/header.php'); ?>
<style>
    body {
        background-color: #14161d !important;
        background-image: none !important;
    }
</style>
<div class="text-center flex flex-col justify-center items-center mt-20">
    <h1 class="font-bold text-white text-2xl mx-40"><?php echo $data['title'] ?></h1>
    <div class="w-full px-32">
        <div class="b py-2 text-sm rounded mt-3 text-white " style="background-color: #222222;">
            <a href="/" class="hover:text-red-400"><?php echo APP_NAME ?></a> > <a class="hover:text-red-400" href="<?php echo APP_URL ?>/manga/<?php echo $data['slug'] ?>">
                <?php echo str_replace(" Chapter " . $data['current_chapter'], " ", $data['title']) ?> </a>> Chapter <?php echo $data['current_chapter'] ?>
        </div>
        <div class="flex  mt-5 items-center justify-between">
            <select name="" id="" onchange="javascript:handleSelect(this)" class="px-10 focus:outline-none rounded py-2 shadow-lg text-white" style="background-color: #222222;">
                <option value="" class="text-sm" disabled>Select Chapter</option>
                <?php foreach ($data['all_chapter'] as $list) {
                    $if1 = explode(" ", $list['title'])[1];
                    $if2 = explode("/", $list['url'])[1];
                ?>
                    <option value="<?php echo $list['url'] ?>" class="text-sm" <?php if ($list['num'] == $data['current_chapter']) { ?> selected <?php } ?>>Chapter <?php echo $list['num'] ?></option>
                <?php } ?>
            </select>
            <div class="flex gap-3">
                <a class="text-white hover:text-red-400 <?php echo $data['prev_chapter'] == "" ? 'hidden' : 'block' ?>" href="<?php echo APP_URL ?>/read/<?php echo $data['prev_chapter'] ?>">Prev Chapter</a>
                <a class="text-white hover:text-red-400 <?php echo $data['next_chapter'] == "" ? 'hidden' : 'block' ?>" href="<?php echo APP_URL ?>/read/<?php echo $data['next_chapter'] ?>">Next Chapter</a>
            </div>
        </div>
    </div>
    <div class="mt-10 px-32">
        <?php foreach ($data['img'] as $img) { ?>
            <img class="w-full object-cover coklah" data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $img ?>">
        <?php } ?>
    </div>
</div>
<script type="text/javascript">
    function handleSelect(elm) {
        window.open(window.location.origin + "/read/" + elm.value, "_blank")
    }
</script>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <div id="disqus_thread"></div>
</div>
<script>
    /**
     *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
     *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
        var d = document,
            s = d.createElement('script');
        s.src = 'https://dramayu-1.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    })();
</script>

<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<?php include(__DIR__ . '/layouts/footer.php'); ?>