<?php include(__DIR__ . '/layouts/header.php'); ?>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <main class="mt-5  rounded-xl ml-3 pt-4 pb-10 ">
        <div class="w-full bg-white px-3 py-3 rounded">
            <h1 class="font-bold text-red-400 text-3xl text-center"><?php echo $data['title'] ?></h1>
            <div class="flex gap-3 mt-5 flex-col lg:flex-row md:flex-row justify-center items-center content-center lg:items-start lg:content-center">
                <img class="w-80 object-cover h-80 rounded coklah" data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $data['img'] ?>" alt="<?php echo $data['title'] ?>">
                <div class="w-full">
                    <span class="text-sm uppercase font-bold">Summary</span>
                    <p class="mt-3 text-gray-500 text-sm ">"<?php echo $data['desc'] ?>"</p>
                    <div class="mt-3">
                        <ul>
                            <li class="text-sm font-semibold text-gray-400 hover:text-red-400"> <span class="text-base font-semibold text-gray-500">Alternative Title :</span> <?php echo $data['altTitle'] == "" ? "-" : $data['altTitle'] ?></li>
                            <li class="text-sm font-semibold text-gray-400 hover:text-red-400"> <span class="text-base font-semibold text-gray-500">Type : </span><?php echo $data['type'] ?></li>
                            <li class="text-sm font-semibold text-gray-400 hover:text-red-400"> <span class="text-base font-semibold text-gray-500">Rating : </span><?php echo $data['rating'] ?></li>
                            <li class="text-sm font-semibold text-gray-400 hover:text-red-400 uppercase"> <span class="text-base font-semibold text-gray-500 normal-case">Status: </span><?php echo $data['status'] ?></li>
                            <li class="text-sm font-semibold text-gray-400">
                                <span class="text-base font-semibold text-gray-500">Genres :</span>
                                <?php foreach ($data['genre'] as $gens) { ?>
                                    <a class="hover:text-red-400" href="/genres/<?php echo $gens ?>"> <?php echo $gens ?></a>
                                <?php } ?>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <div class="flex gap-4 lg:flex-row flex-col">
            <div class=" w-full lg:w-8/12 bg-white px-3 py-3 rounded-b">
                <div class=" overflow-auto px-2" style="max-height: 720px;">
                    <ul>
                        <?php foreach ($data['chapter'] as $chapter) { ?>
                            <li class="w-full flex border px-2 py-3 rounded items-center mb-2">
                                <div class="w-full font-bold text-red-400"><a href="<?php echo str_replace('/all-pages', '', str_replace('manga', 'read', $chapter['url'])) ?>"><?php echo $chapter['name'] ?></a></div>
                                <div class="w-full text-right text-sm font-semibold text-gray-500"><?php echo $chapter['time'] ?></div>
                            </li>
                        <?php } ?>

                    </ul>
                </div>
            </div>
            <div class="w-full lg:w-4/12">
                <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
                <div class="mt-2">
                    <ul class="flex flex-wrap gap-2">
                        <?php foreach ($data['genres'] as $genre) { ?>
                            <li style="width: 48.7%;"><a href="/genres/<?php echo $genre ?>" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                        <?php } ?>
                    </ul>
                </div>
            </div>
        </div>
    </main>

</div>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <div id="disqus_thread"></div>
</div>
<script>
    /**
     *  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
     *  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables    */
    /*
    var disqus_config = function () {
    this.page.url = PAGE_URL;  // Replace PAGE_URL with your page's canonical URL variable
    this.page.identifier = PAGE_IDENTIFIER; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
    };
    */
    (function() { // DON'T EDIT BELOW THIS LINE
        var d = document,
            s = d.createElement('script');
        s.src = 'https://dramayu-1.disqus.com/embed.js';
        s.setAttribute('data-timestamp', +new Date());
        (d.head || d.body).appendChild(s);
    })();
</script>
<noscript>Please enable JavaScript to view the <a href="https://disqus.com/?ref_noscript">comments powered by Disqus.</a></noscript>

<?php include(__DIR__ . '/layouts/footer.php'); ?>