<?php include(__DIR__ . '/layouts/header.php'); ?>
<div class="relative -mt-16 min-h-screen overflow-hidden">
  <div class="absolute inset-0 z-negative opacity-25 z-0">
    <img src="/assets/img/vip-bg.jpg" alt="not found" class="-mt-16 h-full object-cover min-w-full max-w-none">
  </div>
  <div class="container relative mx-auto text-center my-8 pt-32 md:pt-48 lg:pt-56 z-10">
    <h1 class="text-black text-2xl font-bold block">404</h1>
    <p class="text-black text-2xl font-semibold block">Not found</p>
    <a class="font-bold py-2 px-4 bg-orange-600 rounded mt-4 inline-block text-black" href="/" rel="prefetch">
      Home</a>
  </div>
</div>
<?php include(__DIR__ . '/layouts/footer.php'); ?>