<?php include(__DIR__ . '/layouts/header.php'); ?>

<style>
    .tooltip {
        visibility: hidden;
        position: absolute;
    }

    .has-tooltip:hover .tooltip {
        visibility: visible;
        z-index: 50;
    }

    @media only screen and (min-width: 1024px) {
        .pant {
            width: 32%;
        }

        .oys {
            width: 15.666667%;
        }
    }
</style>
<div class="lg:px-28 px-7 md:px-14 mt-10">
    <main class=" mt-5 flex gap-4 rounded-xl ml-3 pt-4 pb-10 lg:flex-row flex-col">
        <div class=" w-full lg:w-8/12 ">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Latest</span> Update</h2>
            <div class="mt-2 flex gap-2 flex-col lg:flex-wrap lg:flex-row">
                <?php foreach ($data['latest'] as $latest) { ?>
                    <div class="bg-gray-500 text-white px-2 rounded py-2 flex pant">
                        <img class="rounded-full w-16 h-16 object-cover lg:w-16 lg:h-16 coklah"alt="<?php echo $latest['manga']['img'] ?>"  data-src="<?php echo CDN_URL ?>?url=https://www.readm.org/<?php echo $latest['manga']['img'] ?>" alt="">
                        <div style="width: 70%;" class="flex flex-col justify-center">
                            <a href="<?php echo $latest['manga']['url'] ?>">
                                <div class="m-3 mt-1 truncate has-tooltip font-semibold">
                                    <span class='tooltip hidden lg:block transition duration-200 rounded shadow-2xl py-2 px-3 bg-red-400 -ml-12 -mt-14 text-sm  font-semibold text-white'>
                                        <?php echo $latest['manga']['title'] ?>
                                    </span>
                                    <?php echo $latest['manga']['title'] ?>
                                </div>
                            </a>
                            <div class="flex ml-4 gap-2 flex-wrap">
                                <?php foreach ($latest['chapter'] as $chLatest) { ?>
                                    <a href="<?php echo str_replace('/all-pages', '', str_replace('manga', 'read', $chLatest['url'])) ?>" class="border-2 hover:bg-red-400 hover:border-transparent transition duration-200 rounded" style="padding: 0.20rem;font-size: 12px;"><?php echo $chLatest['title'] ?></a>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>
            <?php include __DIR__ . '/inc/pagination.php'; ?>

        </div>
        <div class="w-full lg:w-4/12">
            <h2 class="m-0 text-gray-600 font-bold text-xl"><span class="font-extrabold text-red-400">Genres</span> </h2>
            <div class="mt-2">
                <ul class="flex flex-wrap gap-2">
                    <?php foreach ($data['genres'] as $genre) { ?>
                        <li style="width: 48.7%;"><a href="/genres/<?php echo $genre ?>" class="bg-red-400 text-white font-semibold text-sm shadow-lg text-center py-1 rounded block"><?php echo $genre ?></a></li>
                    <?php } ?>
                </ul>
            </div>
        </div>
    </main>
</div>
<?php include(__DIR__ . '/layouts/footer.php'); ?>