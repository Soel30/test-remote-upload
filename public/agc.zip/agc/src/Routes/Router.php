<?php

use App\Lib\Router;

$router = new Router();
$router->setNamespace('\App\Controllers');

$router->get('/', 'IndexController@index');
$router->get('/latest-manga', 'IndexController@latest');
$router->get('/manga/{slug}', 'IndexController@detail');
$router->get('/read/{slug}/{chapter}', 'IndexController@read');

$router->get('/latest-releases', 'IndexController@latest');
$router->get('/latest-releases/{slug}', 'IndexController@latestPage');

// $router->get('/manga-list', 'IndexController@mangalist');
// $router->get('/manga-list/{slug}', 'IndexController@mangalistSearch');

$router->get('/popular-manga', 'IndexController@popular');
$router->get('/popular-manga/{slug}', 'IndexController@popularSlug');


$router->get('/genres/{slug}/page/{page}', 'IndexController@genresPage');
$router->get('/genres/{slug}', 'IndexController@genres');

$router->get('/search', 'IndexController@search');
$router->set404('IndexController@notFound');
$router->run();
