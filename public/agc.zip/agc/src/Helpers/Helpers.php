<?php

namespace App\Helpers;

class Helpers
{
  public static function view($file_path, $data = null, $title = null, $metas = null)
  {
    $title = $title;
    $data = $data;
    $metas = $metas;
    include VIEW_PATH . "/" . $file_path . ".php";
  }

  function checkRemoteFile($url)
  {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    // don't download content
    curl_setopt($ch, CURLOPT_NOBODY, 1);
    curl_setopt($ch, CURLOPT_FAILONERROR, 1);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

    $result = curl_exec($ch);
    curl_close($ch);
    if ($result !== FALSE) {
      return true;
    } else {
      return false;
    }
  }

  public static function createSlug($str, $limit = 50)
  {
    $replacements = array(
      'Š' => 'S', 'š' => 's', 'Ð' => 'Dj', 'Ž' => 'Z', 'ž' => 'z', 'À' => 'A', 'Á' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A',
      'Å' => 'A', 'Æ' => 'A', 'Ç' => 'C', 'È' => 'E', 'É' => 'E', 'Ê' => 'E', 'Ë' => 'E', 'Ì' => 'I', 'Í' => 'I', 'Î' => 'I',
      'Ï' => 'I', 'Ñ' => 'N', 'Ò' => 'O', 'Ó' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O', 'Ø' => 'O', 'Ù' => 'U', 'Ú' => 'U',
      'Û' => 'U', 'Ü' => 'U', 'Ý' => 'Y', 'Þ' => 'B', 'ß' => 'Ss', 'à' => 'a', 'á' => 'a', 'â' => 'a', 'ã' => 'a', 'ä' => 'a',
      'å' => 'a', 'æ' => 'a', 'ç' => 'c', 'è' => 'e', 'é' => 'e', 'ê' => 'e', 'ë' => 'e', 'ì' => 'i', 'í' => 'i', 'î' => 'i',
      'ï' => 'i', 'ð' => 'o', 'ñ' => 'n', 'ò' => 'o', 'ó' => 'o', 'ô' => 'o', 'õ' => 'o', 'ö' => 'o', 'ø' => 'o', 'ù' => 'u',
      'ú' => 'u', 'û' => 'u', 'ý' => 'y', 'ý' => 'y', 'þ' => 'b', 'ÿ' => 'y', 'ƒ' => 'f', '&' => 'and'
    );

    $str = strtr($str, $replacements); // Replace accented/special characters
    $str = preg_replace('/\s+/', '-', trim($str)); // Trim and remove spaces
    $str = str_replace('_', '-', $str); // Underscores to dashes
    $str = preg_replace('/[^a-z0-9-]/i', '', strtolower($str)); // Only alpha-numeric and dashes are permitted
    $str = preg_replace('/-+/', '-', $str); // Prevent 2+ dashes from appearing together

    // Limit the number of characters
    if (intval($limit) > 0) {
      $str = substr($str, 0, intval($limit));
    }

    // Don't end in a dash
    if (substr($str, -1, 1) === '-') {
      $str = substr($str, 0, -1);
    }

    return $str;
  }
}
