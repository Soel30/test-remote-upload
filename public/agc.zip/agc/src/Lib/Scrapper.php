<?php

namespace App\Lib;

use App\Helpers\Helpers;
use voku\helper\HtmlDomParser;
use Ausi\SlugGenerator\SlugGenerator;

class Scrapper
{

  public function setup($path)
  {
    $baseTarget = SCRAPE_URL;
    $curl = curl_init($baseTarget . $path);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13)     Gecko/20080311 Firefox/2.0.0.13');
    $html = curl_exec($curl);
    curl_close($curl);

    return HtmlDomParser::str_get_html($html);
  }

  public function convertSlug($slug, $title)
  {
    $text = str_replace('https://www.mangaread.org/manga/', '', $slug);
    preg_match('/[a-z]+[0-9]+/si', $text, $match);
    if (!$match) return $text . '-read-manga-online';
    return $text  . '-read-manga-online';
  }

  public function getHome()
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/");

    foreach ($html->findOne("ul#latest_trailers")->findMulti("li") as $item) {
      $title = $item->findOne("h6")->text();
      $image = SCRAPE_URL . $item->findOne("img")->getAttribute("data-src");
      $url = $item->findOne('a')->getAttribute('href') . "-a-" . $generator->generate($title);
      $data['popular'][] = [
        'manga' => [
          'title' => $title,
          'img' => $image,
          'url' => $url,
        ],
        'chapter' => [
          'title' => $item->childNodes(2)->findOne('small')->text(),
          'url' => $item->childNodes(2)->findOne('a')->getAttribute('href'),
        ]
      ];
    }

    foreach ($html->findOne('ul:nth-child(7).latest-updates')->findMulti('li') as $ite) {
      $titlex = $ite->findOne('h2 a')->text();
      $urlx = $ite->findOne('h2 a')->getAttribute('href') . "-a-" . $generator->generate($titlex);
      $chapter = [];
      foreach ($ite->findOne('ul.chapters')->findMulti('li') as $te) {
        $chapter[] = [
          'title' => $te->findOne('a')->text(),
          'url' => $te->findOne('a')->getAttribute('href')
        ];
      }
      if ($titlex != "") {
        $data['latest'][] = [
          'manga' => [
            'title' => $titlex,
            'url' => $urlx,
            'img' => str_replace("30x0", "198x0", $ite->findOne('img')->getAttribute('data-src'))
          ],
          'chapter' => $chapter
        ];
      }
    }

    foreach ($html->findOne("#router-view > div > div.ui.grid.mt-0.mb-0 > div > ul")->findMulti('li.segment-poster') as $recent) {
      $urly = $recent->findOne('.poster-subject a')->getAttribute('href') . "-a-" . $generator->generate($recent->findOne('.poster-subject a h2')->text());
      $data['recently'][] = [
        'title' => $recent->findOne('.poster-subject a h2')->text(),
        'url' => $urly,
        'img' => $recent->findOne('.poster-media img')->getAttribute('data-src')
      ];
    }
    $data['genres'] = $this->getGenre();
    return $data;
  }

  public function getGenre()
  {
    $html = $this->setup("/");
    $data = [];
    foreach ($html->findOne('ul.categories')->findMulti('li') as $genres) {
      $data[] = $genres->findOne('a h5')->text();
    }
    return $data;
  }

  public function getDetail($slug)
  {
    $html = $this->setup("/manga/" . $slug);
    $data = [];
    $desc = str_replace('"', "", $html->findOne('#series-profile-content-wrapper > article > div.series-summary-wrapper >  p:nth-child(3)')->text());
    $title = $html->findOne("#router-view > div > div.ui.grid > div.left.floated.sixteen.wide.tablet.eight.wide.computer.column > a > h1")->text();
    $altTitle = $html->findOne('#router-view > div > div.ui.grid > div.left.floated.sixteen.wide.tablet.eight.wide.computer.column > div')->text();
    $genre = [];
    $status = $html->findOne('#router-view > div > div.series-genres > span')->text();
    $rating = $html->findOne('#series-profile-content-wrapper > article > div.media-meta > table > tbody > tr > td:nth-child(4) > div.color-imdb')->text();
    $type = $html->findOne('#series-profile-content-wrapper > article > div.media-meta > table > tbody > tr > td:nth-child(1) > div:nth-child(2)')->text();
    foreach ($html->findOne('#series-profile-content-wrapper > article > div.series-summary-wrapper > div > div')->findMulti('a') as $gen) {
      $genres[] = $gen->text();
    }
    $img = $html->findOne('#series-profile-image-wrapper > img')->getAttribute('src');
    $chapter = [];
    foreach ($html->findOne('#router-view > div > div.ui.tab.tab-segment.active > div.common-lists.pt-sm > div > div.sixteen.wide.tablet.eleven.wide.computer.column > section > div > div.sixteen.wide.tablet.thirteen.wide.stretched.computer.column.season-list-column')->findMulti('div.ui.tab')
      as $chaps) {
      foreach ($chaps->findOne('div.tabular-content div.episodes-list div.ui.list') as $chap) {
        if ($chap->findOne('td#table-episodes-title.table-episodes-title h6 a')->text() != '') {
          $chapter[] = [
            'name' => $chap->findOne('td#table-episodes-title.table-episodes-title h6 a')->text(),
            'url' => $chap->findOne('td#table-episodes-title.table-episodes-title h6 a')->getAttribute('href'),
            'time' => $chap->findOne('td.episode-date')->text(),
          ];
        }
      }
    }
    $data = [
      'title' => $title,
      'desc' => $desc,
      'altTitle' => $altTitle,
      'img' => $img,
      'type' => $type,
      'status' => $status,
      'rating' => $rating,
      'genre' => $genres,

      'chapter' => $chapter,
    ];
    $data['genres'] = $this->getGenre();

    return $data;
  }

  public function readChapter($slug, $chapter)
  {
    $data = [];
    $html = $this->setup("/manga/" . $slug . "/" . $chapter . "/all-pages");
    foreach ($html->findOne('#router-view > div > div.ui.grid.chapter > div.ch-images.ch-image-container >center')->findMulti('img') as $imgs) {
      $data['img'][] = $imgs->getAttribute('src');
    }
    $chapters = [];
    foreach ($html->findOne('div.menu.transition.hidden.category-sort')->findMulti('a') as $ch) {
      $data['all_chapter'][]  = [
        'title' => $ch->text(),
        'url' => str_replace('/all-pages', "", str_replace('/manga/', "",  $ch->getAttribute('href'))),
        'num' => explode('/', str_replace('/all-pages', "", str_replace('/manga/', "",  $ch->getAttribute('href'))))[1],
      ];
    }
    $data['title'] = $html->findOne('title')->text();
    $data['current_chapter'] = str_replace('Chapter ', "", $html->findOne('#router-view > div > div.ui.grid.mt-0 > div.left.floated.sixteen.wide.tablet.sixteen.wide.computer.column > h1 > span')->text());
    $data['next_chapter'] = str_replace('/all-pages', "", str_replace('/manga/', "",  $html->findOne('.item.navigate.ch-next-page.navigate-next')->getAttribute('href')));
    $data['prev_chapter'] = str_replace('/all-pages', "", str_replace('/manga/', "",  $html->findOne('.item.navigate.ch-prev-page.navigate-prev.right')->getAttribute('href')));
    $data['slug'] = $slug;
    return $data;
  }

  public function getLatest()
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/latest-releases");

    foreach ($html->findOne('#router-view > div > ul')->findMulti('li') as $ite) {
      $titlex = $ite->findOne('h2 a')->text();
      $urlx = $ite->findOne('h2 a')->getAttribute('href') . "-a-" . $generator->generate($titlex);
      $chapter = [];
      foreach ($ite->findOne('ul.chapters')->findMulti('li') as $te) {
        $chapter[] = [
          'title' => $te->findOne('a')->text(),
          'url' => $te->findOne('a')->getAttribute('href')
        ];
      }
      if ($titlex != "") {
        $data['latest'][] = [
          'manga' => [
            'title' => $titlex,
            'url' => $urlx,
            'img' => str_replace("30x0", "198x0", $ite->findOne('img')->getAttribute('data-src'))
          ],
          'chapter' => $chapter
        ];
      }
    }

    $data['genres'] = $this->getGenre();
    foreach ($html->findOne('#router-view > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->getAttribute('href'),
        'active' => $html->findOne('#router-view > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }

    // echo json_encode($data);
    return $data;
  }

  public function getLatestPage($slug)
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/latest-releases/" . $slug);

    foreach ($html->findOne('#router-view > div > ul')->findMulti('li') as $ite) {
      $titlex = $ite->findOne('h2 a')->text();
      $urlx = $ite->findOne('h2 a')->getAttribute('href') . "-a-" . $generator->generate($titlex);
      $chapter = [];
      foreach ($ite->findOne('ul.chapters')->findMulti('li') as $te) {
        $chapter[] = [
          'title' => $te->findOne('a')->text(),
          'url' => $te->findOne('a')->getAttribute('href')
        ];
      }
      if ($titlex != "") {
        $data['latest'][] = [
          'manga' => [
            'title' => $titlex,
            'url' => $urlx,
            'img' => str_replace("30x0", "198x0", $ite->findOne('img')->getAttribute('data-src'))
          ],
          'chapter' => $chapter
        ];
      }
    }

    $data['genres'] = $this->getGenre();
    foreach ($html->findOne('#router-view > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->getAttribute('href'),
        'active' => $html->findOne('#router-view > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }
    return $data;
  }

  public function mangaList()
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/manga-list");

    foreach ($html->findOne('#router-view > div.dark-segment > ul')->findMulti('li') as $ite) {
      $titlex = $ite->findOne('div.poster-subject h2')->text();
      $urlx = $ite->findOne('.poster a')->getAttribute('href') . "-a-" . $generator->generate($titlex);
      if ($titlex != "") {
        $data['list'][] = [
          'manga' => [
            'title' => $titlex,
            'url' => $urlx,
            'img' => str_replace("30x0", "198x0", $ite->findOne('img')->getAttribute('data-src')),
            'staux' => $ite->findOne('span.episode-no')->text()
          ]
        ];
      }
    }

    $data['genres'] = $this->getGenre();

    // echo json_encode($data);
    // echo $html;
    return $data;
  }

  public function mangaListSearch($slug)
  {
    $newSlug = strtolower($slug);
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/manga-list/" . $newSlug);

    foreach ($html->findOne('#router-view > div.dark-segment > ul')->findMulti('li') as $ite) {
      $titlex = $ite->findOne('div.poster-subject h2')->text();
      $urlx = $ite->findOne('.poster a')->getAttribute('href') . "-a-" . $generator->generate($titlex);
      if ($titlex != "") {
        $data['list'][] = [
          'manga' => [
            'title' => $titlex,
            'url' => $urlx,
            'img' => str_replace("30x0", "198x0", $ite->findOne('img')->getAttribute('data-src')),
            'staux' => $ite->findOne('span.episode-no')->text()
          ]
        ];
      }
    }

    $data['genres'] = $this->getGenre();
    $data['slug'] = $newSlug;
    // echo json_encode($data);
    // echo $html;
    return $data;
  }

  public function popularManga()
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/popular-manga");

    foreach ($html->findOne('#discover-response > ul')->findMulti('li') as $popular) {
      $genres = [];

      foreach ($popular->findOne('div.poster-with-subject > div > div > div > p > span')->findMulti('a') as $gn) {
        $genres[] = $gn->text();
      }
      $data['manga'][] = [
        'title' => $popular->findOne('div.poster-with-subject > div > div > div > a')->text(),
        'url' => $popular->findOne('div.poster-with-subject > div > div > div > a')->getAttribute('href') . "-a-" . $generator->generate($popular->findOne('div.poster-with-subject > div > div > div > a')->text()),
        'img' => $popular->findOne('img')->getAttribute('src'),
        'type' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(2) > div:nth-child(2)')->text(),
        'rating' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(4) > div.color-imdb')->text(),
        'desc' => $popular->findOne('div.poster-with-subject > div > p')->text(),
        'genre' => $genres
      ];
    }
    foreach ($html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->getAttribute('href'),
        'active' => $html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }
    $data['genres'] = $this->getGenre();
    return $data;
  }

  public function popularMangaList($slug)
  {
    $generator = new SlugGenerator;
    $data = [];
    $html = $this->setup("/popular-manga/" . $slug);

    foreach ($html->findOne('#discover-response > ul')->findMulti('li') as $popular) {
      $genres = [];

      foreach ($popular->findOne('div.poster-with-subject > div > div > div > p > span')->findMulti('a') as $gn) {
        $genres[] = $gn->text();
      }
      $data['manga'][] = [
        'title' => $popular->findOne('div.poster-with-subject > div > div > div > a')->text(),
        'url' => $popular->findOne('div.poster-with-subject > div > div > div > a')->getAttribute('href') . "-a-" . $generator->generate($popular->findOne('div.poster-with-subject > div > div > div > a')->text()),
        'img' => $popular->findOne('img')->getAttribute('src'),
        'type' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(2) > div:nth-child(2)')->text(),
        'rating' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(4) > div.color-imdb')->text(),
        'desc' => $popular->findOne('div.poster-with-subject > div > p')->text(),
        'genre' => $genres
      ];
    }

    foreach ($html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->getAttribute('href'),
        'active' => $html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }

    $data['genres'] = $this->getGenre();
    return $data;
  }

  public function getGenreList($slug)
  {
    $generator = new SlugGenerator;
    $data = [];
    $data['title'] = $slug;

    $newSlug = $generator->generate($slug);
    $html = $this->setup("/category/" . $newSlug);


    foreach ($html->findOne('#discover-response > ul')->findMulti('li') as $popular) {
      $genres = [];

      foreach ($popular->findOne('div.poster-with-subject > div > div > div > p > span')->findMulti('a') as $gn) {
        $genres[] = $gn->text();
      }
      $data['manga'][] = [
        'title' => $popular->findOne('div.poster-with-subject > div > div > div > a')->text(),
        'url' => $popular->findOne('div.poster-with-subject > div > div > div > a')->getAttribute('href') . "-a-" . $generator->generate($popular->findOne('div.poster-with-subject > div > div > div > a')->text()),
        'img' => $popular->findOne('img')->getAttribute('data-src'),
        'type' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(2) > div:nth-child(2)')->text(),
        'rating' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(3) > div.color-imdb')->text(),
        'desc' => $popular->findOne('div.poster-with-subject > div > p')->text(),
        'genre' => $genres
      ];
    }

    foreach ($html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->text() == "1" ? "/genres/" . $slug : str_replace("/watch", "/page", str_replace('/category', "/genres", $pagin->getAttribute('href'))),
        'active' => $html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }

    $data['genres'] = $this->getGenre();
    return $data;
  }

  public function getGenreListPage($slug, $page)
  {
    $generator = new SlugGenerator;
    $data = [];
    $newSlug = $generator->generate($slug);
    $html = $this->setup("/category/" . $newSlug . '/watch/' . $page);
    foreach ($html->findOne('#discover-response > ul')->findMulti('li') as $popular) {
      $genres = [];
      foreach ($popular->findOne('div.poster-with-subject > div > div > div > p > span')->findMulti('a') as $gn) {
        $genres[] = $gn->text();
      }
      $data['title'] = $slug;
      $data['manga'][] = [
        'title' => $popular->findOne('div.poster-with-subject > div > div > div > a')->text(),
        'url' => $popular->findOne('div.poster-with-subject > div > div > div > a')->getAttribute('href') . "-a-" . $generator->generate($popular->findOne('div.poster-with-subject > div > div > div > a')->text()),
        'img' => $popular->findOne('img')->getAttribute('data-src'),
        'type' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(2) > div:nth-child(2)')->text(),
        'rating' => $popular->findOne('div.media-meta > table > tbody > tr > td:nth-child(3) > div.color-imdb')->text(),
        'desc' => $popular->findOne('div.poster-with-subject > div > p')->text(),
        'genre' => $genres
      ];
    }

    foreach ($html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu')->findMulti('li a') as $pagin) {
      $data['pagination'][] = [
        'text' => $pagin->text(),
        'url' => $pagin->text() == "1" ? "/genres/" . $slug : str_replace("/watch", "/page", str_replace('/category', "/genres", $pagin->getAttribute('href'))),
        'active' => $html->findOne('#router-view > div.bg-cover-faker > div > div > div.ui.pagination.menu > li.item.active')->text()
      ];
    }

    $data['genres'] = $this->getGenre();
    return $data;
  }

  public function search($search)
  {
    $url = 'https://www.readm.org/service/search';

    $ch = curl_init($url);

    $data = [
      'dataType' => 'json',
      'phrase' => $search
    ];

    $headers = array(
      "Accept: */*",
      "Content-Type: application/x-www-form-urlencoded",
      "Referer: https://www.readm.org/",
      "Origin: https://www.readm.org",
      "x-requested-with: XMLHttpRequest",
      "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36 Edg/91.0.864.5"
    );

    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    $result = curl_exec($ch);
    curl_close($ch);
    $datax =  json_decode($result, true);
    $datax['genres'] = $this->getGenre();
    return $datax;
  }
}
